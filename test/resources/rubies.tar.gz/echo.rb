#!/usr/bin/ruby -w
puts ARGV.join(' ')
